# WEATHER-APP.1
-WEATHER APP enables anyone to search for their wanted weather city condition and details.

*USER ON PYTHON IDE  :
1- Install python IDE and make sure new projects are linked or go to path.
2- download and import all the weather app files into your IDE
3- Run the Weather app, make sure you have internet so APIs can work efficiently.
4-- Insert the city weather you want and search .

*USER WITH NO PYTHON IDE  :
1- download the weather app executable (exe) file
2- Run the Weather app, make sure you have internet so APIs can work efficiently.
3- Insert the city weather you want and search .
